def in_common(l1, l2):
    pass


def calc_score(netflix_history1, netflix_history2, fav_books1, fav_books2):
    """
    >>> percent_in_common(['a', 'b', 'c', 'd'], ['c', 'd', 'm', 'n', 'x', 'z'])
    0.2
    """
    pass


def new_friend(name_list, compatibility_scores):
    """
    >>> name_list = ['Michelle', 'Joe']
    >>> compability_scores = [1, 0.8]
    >>> new_friend(name_list, compatibility_scores)
    ['Michelle', 1]
    """
    pass
