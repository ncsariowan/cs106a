def read_dict_from_file(filename):
    pass


def can_make(recipe, pantry):
    pass


def make_recipe(recipe, pantry):
    pass


def main():
    pass


if __name__ == "__main__":
    main()
