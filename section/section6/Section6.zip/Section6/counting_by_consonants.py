def count_by_consonants(filename):
    """
    Reads in the file whose name is filename and returns a dictionary
    that contains counts of words that share the same consonants in order.
    """
    pass


def main():
    filename = input("Filename: ")
    print(count_by_consonants(filename))


if __name__ == "__main__":
    main()
