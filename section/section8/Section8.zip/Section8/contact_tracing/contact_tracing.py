"""
File: contract_tracing.py
-------------------------

Uses the information in locations.txt to get a list of everyone that came in
contact with the target throughout the day.
"""

TARGET = 'Rosalind'
LOCATION_FILE = 'locations.txt'


def find_contacts(target, location_file):
    """
    Computes and returns a list of people that the target came in contact with
    by processing the location file.

    Arguments
    ---------
    target (str) -- The name of the person to compare everyone against.
    location_file (str) -- The name of the file that contains the location
        information for people throughout the day.

    Returns
    -------
    list [str] -- A list of people who came in contact with the target during
        the day.
    """
    pass


def main():
    find_contacts(TARGET, LOCATION_FILE)


if __name__ == '__main__':
    main()