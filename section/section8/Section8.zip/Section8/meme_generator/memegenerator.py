from simpleimage import SimpleImage

FONT_FILE = 'impact.ttf'
SIZE = 50
COLOR = 'white'

class MemeGenerator:

    def __init__(self, filename):
        pass

    def set_image(self, filename):
        pass

    def add_text(self, text, x, y):
        pass

    def render(self):
        pass