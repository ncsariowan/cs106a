SAMPLE_INPUT = {
    'Alice': ['Bob', 'Catherine'],
    'Daniel': ['Alice', 'Eve'],
    'Catherine': ['Frank'],
    'Eve': ['Grace']
}
​

def find_grandchildren(parents_dictionary):
    """
    >>> find_grandchildren(SAMPLE_INPUT)
    {'Alice': ['Frank'], 'Daniel': ['Bob', 'Catherine', 'Grace']}
    """
    pass