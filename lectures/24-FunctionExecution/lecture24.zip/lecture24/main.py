"""
File: main.py 
-------------

A program that constructs an instance of a 
PhotoFrame and displays the photo screen
"""

import os
import tkinter

# import the PhotoFrame class from photoframe_soln.py
from photoframe_soln import PhotoFrame 

# import the PhotoFrame class from photoframe.py
# from photoframe import PhotoFrame 

VALID_IMAGE_EXTENSIONS = [".png", ".jpg"]
# a folder containing the images you want to display
PHOTO_FOLDER_NAME = 'simba_and_buddy'  

# dimensions of the canvas
CANVAS_WIDTH = 800
CANVAS_HEIGHT = 600

def load_photos_from_list(folder_name):
    """
    PROVIDED FUNCTION

    Given the name of a folder containing images to be displayed,
    returns a list of all the filenames ending with either .png 
    or .jpg 

    You don't need to understand how this function works, but it's 
    commented exhaustively in case you're interested 
    """
    images = []
    # os.listdir returns a list of all the filenames in a folder 
    for filename in os.listdir(folder_name):
        # os.path.splittext returns a tuple whose first element 
        # is the filename without the file extension and whose 
        # second element is the file extension. For example,
        # os.path.splittext('simba.jpg') would return ('simba', '.jpg').
        filename_without_extension, file_extension = os.path.splitext(filename)
        
        # check that the image has a valid file extension and append it 
        # to images if so. 
        if file_extension in VALID_IMAGE_EXTENSIONS:
            images.append(os.path.join(PHOTO_FOLDER_NAME, filename))

    return images


def make_canvas(width, height):
    """
    DO NOT MODIFY
    Creates and returns a drawing canvas of the
    of the given int size, ready for drawing.
    """
    top = tkinter.Tk()
    top.minsize(width=width + 10, height=height + 10)
    top.title('Photo Frame')
    canvas = tkinter.Canvas(top, width=width + 1, height=height + 1)
    canvas.pack()
    canvas.xview_scroll(8, 'units')  # add this so (0, 0) works correctly
    canvas.yview_scroll(8, 'units')  # otherwise it's clipped off
    return top, canvas

def main():
    # In general, we can add all our buttons to a canvas, but
    # in practice, programmers often define a 'root' window, 
    # which they place the canvas on, and then place buttons 
    # separately on the 'root' window. I modified make_canvas
    # to return both the root window (top) as well as canvas. 
    top, canvas = make_canvas(CANVAS_WIDTH, CANVAS_HEIGHT) 

    # load the photos into a list
    photos_list = load_photos_from_list(PHOTO_FOLDER_NAME)
   
    # construct a PhotoFrame object
    frame = PhotoFrame(top, canvas, CANVAS_WIDTH, CANVAS_HEIGHT, photos_list)

    canvas.mainloop()

if __name__ == "__main__":
    main()
