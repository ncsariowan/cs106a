"""
File: photoframe.py 
-------------------

Defines a PhotoFrame class representing a rotating 
gallery of pictures which a user can rotate through. 
"""

import tkinter
from PIL import Image, ImageTk

class PhotoFrame:
    """
    This class maintains several instance variables:
        self.top: the 'root' window for the program 
        self.canvas: the canvas on which images are drawn 
        self.canvas_width: the width of the canvas 
        self.canvas_height: the height of the canvas 
        self.photo_list: a list of photo filenames representing photos to display
        self.photo_position: maintains the 'current position' in the photo list
    """

    def __init__(self, top, canvas, canvas_width, canvas_height, photo_list):
        # first, initialize the instance variables
        self.top = top
        self.canvas = canvas 
        self.canvas_width = canvas_width
        self.canvas_height = canvas_height
        self.photo_list = photo_list
        self.photo_position = 0

        # next, wire up the buttons to modify which
        # picture is being shown. We'll write this 
        # function in class!
        self.setup_buttons()

        # display the initial photo on the canvas
        self.show_photo()
        
    def setup_buttons(self):
        """
        Creates and wires up the buttons on the canvas. Two 
        buttons should be created: one to move to the next photo, 
        and one to move to the previous photo. 

        The self.next_photo and self.prev_photo methods update the 
        object's state to progress and regress the current image, 
        respectively. 
        """
        prev_button = tkinter.Button(
            self.top,
            text='Previous Photo',
            command=self.prev_photo,
        )
        prev_button.pack(side=tkinter.LEFT)

        next_button = tkinter.Button(
            self.top,
            text='Next Photo',
            command=self.next_photo
        )
        next_button.pack(side=tkinter.RIGHT)

    def next_photo(self):
        """
        Updates the current photo to the next one in 
        self.photo_list
        """
        self.photo_position += 1
        # deal with the case where we get to the end of the list
        if self.photo_position == len(self.photo_list):
            self.photo_position = 0

        self.show_photo()
        
    def prev_photo(self):
        """
        Updates the current photo to the previous one in 
        self.photo_list
        """
        self.photo_position -= 1
        # deal with the case where get to the very beginning of 
        # the list
        if self.photo_position == -1:
            self.photo_position = len(self.photo_list) - 1
        
        self.show_photo()

    def show_photo(self):
        # clear the current image from the canvas   
        self.canvas.delete('all')

        # get the current image filename
        filename = self.photo_list[self.photo_position]

        # in order to display images on a canvas, we need to 
        # leverage the Image and ImageTk PhotoImage classes 
        # from the Pillow (PIL) Library. You don't need to 
        # worry too much about the details of how this works.
        image = Image.open(filename)

        # There's a little weirdness here - if we made photo 
        # a local variable (without the 'self.'), it would be 
        # deleted after the show_photo() method returns, so 
        # we make it an instance variable so that the PhotoImage 
        # object doesn't get deleted when the method ends. 
        self.photo = ImageTk.PhotoImage(image)

        # add the canvas to the screen
        self.canvas.create_image(
            self.canvas_width // 2,  # x coordinate
            self.canvas_height // 2, # y coordinate
            anchor=tkinter.CENTER,   # the coordinates specified above are the center of the image
            image=self.photo         # specify which image to add. 
        )
        
        
        
    



        
