"""
File: my_first_button.py 
------------------------

A simple program to demonstrate how a button can 
be added to a canvas, and how we can define a function 
to be called each time the button is clicked. 
"""

import tkinter  

def click_handler():
    """
    This function is called whenever the button is 
    clicked, but we don't ever explicitly call it. 

    The function doesn't accept any parameters, 
    because the button won't give it any. 
    """
    print("The button was clicked!")

def main():
    canvas = make_canvas(100, 100)

    # make a button
    button = tkinter.Button(
        canvas,                  # the button appears on the canvas
        text="Click me!",        # The button says "Click me!"
        command=click_handler    # Whenever the button is clicked,
                                 # click_handler is called
    )
    button.pack()                # add the button to the screen
    canvas.mainloop()

def make_canvas(width, height):
    """
    DO NOT MODIFY
    Creates and returns a drawing canvas of the
    of the given int size, ready for drawing.
    """
    top = tkinter.Tk()
    top.minsize(width=width + 10, height=height + 10)
    top.title('Photo Frame')
    canvas = tkinter.Canvas(top, width=width + 1, height=height + 1)
    canvas.pack()
    canvas.xview_scroll(8, 'units')  # add this so (0, 0) works correctly
    canvas.yview_scroll(8, 'units')  # otherwise it's clipped off
    return canvas

if __name__ == "__main__":
    main()