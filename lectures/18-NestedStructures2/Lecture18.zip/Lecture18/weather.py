import requests
import json 
import os

def main():
	print('weather')
	# TODO: your code here.


if __name__ == '__main__':
	main()