
def main():
	data = [
		"a",
		25,
		{
			"test":"woot"
		}
	]

	print(data)

if __name__ == '__main__':
	main()